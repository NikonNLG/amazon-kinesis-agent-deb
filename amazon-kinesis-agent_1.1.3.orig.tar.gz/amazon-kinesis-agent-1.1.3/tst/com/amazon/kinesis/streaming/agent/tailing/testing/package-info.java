/*
 * Copyright (c) 2014-2017 Amazon.com, Inc. All Rights Reserved.
 */
/**
 * Test support for the package {@code com.amazon.kinesis.streaming.agent.tailing}.
 */
package com.amazon.kinesis.streaming.agent.tailing.testing;